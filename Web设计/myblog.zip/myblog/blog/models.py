from django.db import models
from DUEditor.models import UEditorField
# Create your models here.
class article(models.Model):
    tit = models.CharField('标题',max_length=200)
    img = models.FileField('图片',upload_to='media/img')
    conten = UEditorField('内容')
    c_tim = models.DateField('创建日期')
    def __str__(self):
        return self.tit
        # 为了后台数据显示清晰加此一条 这里显示文章标题方便查看
class coments(models.Model):
    name = models.CharField('name',max_length=100)
    com = models.TextField('留言')
    To = models.ForeignKey(to=article, on_delete=None, related_name='comen')
    tim = models.DateField(auto_now_add=True)
    def __str__(self):
        return self.name
        # 为了后台数据显示清晰加此一条 这里显示name方便查看