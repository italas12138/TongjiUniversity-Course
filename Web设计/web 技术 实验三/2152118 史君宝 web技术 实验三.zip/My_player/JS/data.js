let songs = [
    {
        name: '打上花火',
        music_in: '../mp3/打上花火.mp3',
        image_in: '../image/打上花火.jpg'
    },
    {
        name: '团子大家族',
        music_in: '../mp3/团子大家族.mp3',
        image_in: '../image/团子大家族.jpg'
    },
    {
        name: '想要变得可爱',
        music_in: '../mp3/想要变得可爱.mp3',
        image_in: '../image/想要变得可爱.jpg'
    },
	{
	    name: 'Believe in you',
	    music_in: '../mp3/Believe in you.mp3',
        image_in: '../image/Believe in you.png'
	},
	{
	    name: 'DEJA VU',
	    music_in: '../mp3/DEJA VU.mp3',
        image_in: '../image/DEJA VU.jpeg'
	},
	{
	    name: 'only my railgun',
	    music_in: '../mp3/only my railgun.mp3',
        image_in: '../image/only my railgun.jpg'
	},
	{
	    name: 'Stay Alive',
	    music_in: '../mp3/Stay Alive.mp3',
        image_in: '../image/Stay Alive.jpg'
	},
	{
	    name: 'STYX HELIX',
	    music_in: '../mp3/STYX HELIX.mp3',
        image_in: '../image/STYX HELIX.jpg'
	},
]