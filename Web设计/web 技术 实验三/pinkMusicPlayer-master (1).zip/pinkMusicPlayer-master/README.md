# 一款粉粉的音乐播放器

[Demo](https://wdxlfox.com/pinkMusicPlayer/)

![效果图01](https://github.com/LueStrong/pinkMusicPlayer/blob/master/%E6%95%88%E6%9E%9C%E5%9B%BE/%E6%95%88%E6%9E%9C%E5%9B%BE03.png?raw=true)
![效果图02](https://github.com/LueStrong/pinkMusicPlayer/blob/master/%E6%95%88%E6%9E%9C%E5%9B%BE/%E6%95%88%E6%9E%9C%E5%9B%BE02.png?raw=true)
![效果图03](https://github.com/LueStrong/pinkMusicPlayer/blob/master/%E6%95%88%E6%9E%9C%E5%9B%BE/%E6%95%88%E6%9E%9C%E5%9B%BE01.png?raw=true)
