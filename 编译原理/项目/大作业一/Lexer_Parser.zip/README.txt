如果你点击生成DFA和语法树没有效果

这是因为程序里运用了 Graphviz/bin/dot.exe 

可能你并没有安装，请点击其中的安装程序 Graphviz.exe，将其安装在 C:\Program Files 就可以了