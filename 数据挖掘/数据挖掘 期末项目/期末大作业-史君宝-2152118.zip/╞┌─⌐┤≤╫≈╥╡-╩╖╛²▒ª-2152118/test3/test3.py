import warnings
import matplotlib.pyplot as plt
import numpy as np
import optuna
import pandas as pd
import seaborn as sns

from sklearn import metrics
from sklearn.metrics import log_loss
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier, plot_importance

warnings.filterwarnings("ignore", category=FutureWarning)
plt.style.use("fivethirtyeight")




def prep(df):
    #列名转换为小写
    df.columns =  df.columns.str.lower()

    #去掉id的列
    df = df.drop("id", axis = 1)

    df["age"] = df["age"].divide(365).round(0).astype("int16")

    categorical_vars = df.loc[:, df.nunique() <= 4].columns[0:6]
    numerical_vars = df.loc[:, df.nunique() > 4].columns

    df[categorical_vars] = df[categorical_vars].astype("category")
    
    if (df['name'] == "train_df").all():
        df['status'] = df['status'].map({"C":0, "CL":1, "D":2})

    return df, categorical_vars, numerical_vars



def data_process():
    train_df = pd.read_csv("d:\\playground-series-s3e26\\train.csv")
    print(train_df.head())

    #生成花里胡哨的数据
    train_df.describe().round(2).style.format("{:.2f}").background_gradient(cmap="Blues")

    train_df = train_df.assign(name='train_df')

    train_df, categorical_vars, numerical_vars =  prep(train_df)

    #画饼图
    plt.pie(
    train_df["status"].value_counts(),
    labels = train_df["status"].value_counts().index,
    textprops={"fontsize": 10},
    colors= ["#498964", "#495680", "#de6264"],
    autopct="%.0f%%",
    explode=[0.05, 0.05, 0.05],
    )
    plt.title("Target Variable Distribution", fontsize=14)
    plt.show()


    plt.pie(
    train_df["sex"].value_counts(),
    labels = train_df["sex"].value_counts().index,
    textprops={"fontsize": 12},
    colors=["#c90076", "#2986cc"],
    autopct="%.0f%%",
    explode=[0.05, 0.05],
    )
    plt.title("Gender Distribution", fontsize=14)
    plt.show()



    # sex和age 的组合信息表
    formatted_table = (
        train_df[["sex", "age"]]
        .groupby(["sex"])["age"]
        .agg(["count", "mean", "median", "std"])
        .round(2)
        .reset_index()
    )
    print(formatted_table)

    
    # sex和status 的组合信息表

    sx_vs_status = train_df.groupby(["sex", "status"]).size().reset_index(name="count")
    sx_vs_status = sx_vs_status.round(3)

    sx_vs_status["percent"] = (sx_vs_status["count"] / sx_vs_status["count"].sum()).mul(100).round(2).astype(str) + "%"
    styled_table = sx_vs_status.style.format("{:.2f}").background_gradient(cmap="Blues")

    print(styled_table)






    # 观察 "drug", "ascites", "hepatomegaly", "spiders","stage", "edema" 这些变量的 status 的分布情况表
    for i in ["drug", "ascites", "hepatomegaly", "spiders","stage", "edema"]:
        g = sns.FacetGrid(data=train_df, col=i, height=2.5, aspect=1.5, margin_titles=True)
        g.map_dataframe(
            sns.countplot, x="status", hue="sex", width = 0.4, palette={"F": "#c90076", "M": "#2986cc"}
        )
        g.set_titles(
            col_template="\n---------------------\n{col_var} = {col_name}\n---------------------\n",
            size=8,
        )
        g.add_legend(fontsize=8)
        g.tick_params(labelsize=8)
        g.set_axis_labels(x_var="Status", y_var = "Counts", fontsize = 10)
    
    plt.show()


    

    # 核密度估计图
    plt.style.use("fast")
    ridg_plt_df = pd.melt(train_df[numerical_vars])
    ridg_plt_df["value"] = np.log10(ridg_plt_df["value"])

    g = sns.FacetGrid(
        ridg_plt_df, row="variable", hue="variable", aspect=6, height=1.2, palette="tab10"
    )
    g.map(sns.kdeplot, "value", bw_adjust=1, clip_on=False, fill=True, alpha=1, linewidth=1)
    g.refline(y=0, linewidth=0.2, linestyle="-", color=None, clip_on=False)
    g.set_titles(row_template="\n\n{row_name}", size=10)
    g.set(yticks=[], ylabel="")
    g.set_xlabels("Value [Log10]", fontsize=12)
    g.despine(bottom=True, left=True)
    plt.xticks(fontsize = 9)
    plt.show()


    # 绘制热力图，观察各特征的相关性
    plt.style.use("default")
    corr_mat = train_df[numerical_vars].corr()
    mask = np.triu(np.ones_like(corr_mat, dtype=bool))
    cmap = sns.diverging_palette(230, 30, as_cmap=True)
    f, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(
        corr_mat,
        mask=mask,
        cbar=False,
        cmap=cmap,
        fmt='0.2f',
        center=0,
        square=False,
        annot=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.8}
    )
    plt.title("Correlation Matrix\n")
    plt.xticks(fontsize=9)
    plt.yticks(fontsize=9)
    plt.show()



    train = pd.get_dummies(train_df, columns=categorical_vars, drop_first=True, dtype=int)

    X = train.drop(columns=['status'], axis =1)
    y = train['status']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=8, stratify=y
    )

    





    test_df = pd.read_csv("d:\\playground-series-s3e26\\test.csv")

    test_df = test_df.assign(name='test_df')

    tmp = prep(test_df)
    test_df = tmp[0]
    test_df.info()

    
    test = pd.get_dummies(test_df, columns=categorical_vars, drop_first=True, dtype=int)

    return X_train, X_test, y_train, y_test, test

    

































def objective_xgb(trial):
    # 修正超参数
    params = {
        "booster": trial.suggest_categorical("booster", ["gbtree"]),
        "max_depth": trial.suggest_int("max_depth", 3, 12),
        "learning_rate": trial.suggest_loguniform("learning_rate", 0.01, 0.1),
        "n_estimators": trial.suggest_int("n_estimators", 200, 1000),
        "min_child_weight": trial.suggest_int("min_child_weight", 1, 2),
        "subsample": trial.suggest_loguniform("subsample", 0.1, 1),
        "colsample_bylevel": trial.suggest_float("colsample_bylevel", 0.1, 1),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.1, 1),
        "colsample_bynode": trial.suggest_float("colsample_bynode", 0.1, 1),
        "reg_alpha": trial.suggest_float("reg_alpha", 0.5, 1),
        "reg_lambda": trial.suggest_float("reg_lambda", 0.5, 1),
        "eval_metric": trial.suggest_categorical("eval_metric", ["mlogloss"]),
    }

    # Fit the model
    model_xgb = XGBClassifier(**params, random_state = 8)

    model_xgb.fit(X_train, y_train)

    # Predict and calculate log loss
    y_pred = model_xgb.predict_proba(X_test)

    return log_loss(y_test, y_pred)



if __name__ == '__main__':

    X_train, X_test, y_train, y_test, test = data_process()


    print(1)

    # 获得optuna 和 XGboost组合的模型
    study_xgboost = optuna.create_study(direction='minimize')
    optuna.logging.set_verbosity(optuna.logging.WARNING)  
    study_xgboost.optimize(objective_xgb, n_trials=500, show_progress_bar=True)

    print("Best parameters:", study_xgboost.best_params)


    # 优化历史图表，反映优化过程
    fig = optuna.visualization.plot_optimization_history(study_xgboost)
    fig.update_layout(
        font_family="Courier New",
        font_size=12,
        title_font_family="Times New Roman",
        title_font_color="steelblue",
        legend_title_font_color="black",
        plot_bgcolor='#e9eff6',
        paper_bgcolor='#f5fbf5',
    )
    fig.update_xaxes(color = "darkgreen")
    fig.update_traces(marker_color='green')



    # 超参数切片的图表，我也不知道什么东西
    fig = optuna.visualization.plot_param_importances(study_xgboost)
    fig.update_layout(
        font_family="Courier New",
        font_size=12,
        title_font_family="Times New Roman",
        title_font_color="steelblue",
        legend_title_font_color="black",
        plot_bgcolor='#e9eff6',
        paper_bgcolor='#f5fbf5',
    )
    fig.update_xaxes(color = "darkgreen")
    fig.update_traces(marker_color='green')



    # 超参数重要性反映图表，反映各个超参数的重要性
    fig = optuna.visualization.plot_slice(
        study_xgboost,
        params=[
            "colsample_bylevel",
            "learning_rate",
            "reg_lambda",
            "n_estimators",
            "colsample_bynode",
            "subsample",
            "max_depth",
        ],
    )
    fig.update_layout(
        font_family="Courier New",
        font_size=12,
        title_font_family="Times New Roman",
        title_font_color="steelblue",
        legend_title_font_color="black",
        plot_bgcolor="#e9eff6",
        paper_bgcolor="#f5fbf5",
    )
    fig.update_xaxes(color="darkgreen")



    # 用训练好的模型计算结果的损失值 log_loss
    xgb_final = XGBClassifier(**study_xgboost.best_params, random_state = 8)
    xgb_final.fit(X_train, y_train)

    y_pred = xgb_final.predict_proba(X_test)
    print('Log Loss:', log_loss(y_test, y_pred))


    # 绘制特征重要性的条形图
    #衡量了在构建梯度提升树时，每个特征对模型性能的贡献程度。
    #它通过计算每个特征在树节点分裂过程中所带来的信息增益（或减少的不纯度）来衡量特征的重要性。
    #"Gain" 特征重要性越高，表示该特征在模型中的决策能力越强。
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 12))
    ax1 = plot_importance(
        xgb_final,
        importance_type="gain",
        show_values=False,
        max_num_features = 10,
        ax=ax1,
        title="Feature importance (Gain)",
        xlabel="",
        height=0.7,
        color="#3c82a8",
    )   
    ax1.bar_label(ax1.containers[0], fmt="{:,.01f}", fontsize = 8)
    ax1.grid(False)



    # 绘制特征重要性的条形图
    #衡量了在构建梯度提升树时，每个特征在训练数据中的覆盖程度。
    #它通过计算每个特征在树节点分裂过程中所覆盖的样本数量来衡量特征的重要性。
    #"Cover" 特征重要性越高，表示该特征在训练数据中的分布范围广，对模型的训练起到了更大的作用。
    ax2 = plot_importance(
        xgb_final,
        importance_type="cover",
        show_values=False,
        max_num_features = 10,
        ax=ax2,
        title="Feature importance (Cover)",
        xlabel="",
        height=0.7,
    color="#ef4523",
    )
    ax2.bar_label(ax2.containers[0], fmt="{:,.01f}", fontsize = 8)
    ax2.grid(False)


    # 绘制特征重要性的条形图
    #衡量了在构建梯度提升树时，每个特征被使用的次数。
    #它通过计算每个特征在所有树节点中被使用的次数来衡量特征的重要性。
    #"Weight" 特征重要性越高，表示该特征在构建树时被更频繁地使用，对模型的训练起到了更大的作用。
    ax3 = plot_importance(
        xgb_final,
        importance_type="weight",
        show_values=False,
        max_num_features = 10,
        ax=ax3,
        title="Feature importance (Weight)",
        height=0.7,
        color="#e6ba0b",
    )
    ax3.bar_label(ax3.containers[0], fmt="{:,.01f}", fontsize = 8)
    ax3.grid(False)
    plt.show()


    # 在测试接上绘制混淆矩阵，观察分类效果
    y_pred_cm = xgb_final.predict(X_test)

    fig, ax = plt.subplots(figsize=(5, 5))
    cm = metrics.confusion_matrix(y_test, y_pred_cm, labels=xgb_final.classes_)

    disp = metrics.ConfusionMatrixDisplay(
        confusion_matrix=cm, display_labels=xgb_final.classes_)
    disp.plot(cmap=plt.cm.Reds, ax= ax, 
        colorbar=False, text_kw={"fontsize":12})
    plt.show()


    
    y_pred_test = xgb_final.predict_proba(test)
    y_pred_test

    sample_submission = pd.read_csv("d:\\playground-series-s3e26\\sample_submission.csv")


    sample_submission["Status_C"] =  y_pred_test[:, 0]
    sample_submission["Status_CL"] =  y_pred_test[:,1]
    sample_submission["Status_D"] =  y_pred_test[:, 2]

    sample_submission.to_csv('d:\\playground-series-s3e26\\submission.csv',index=False)
    sample_submission






































