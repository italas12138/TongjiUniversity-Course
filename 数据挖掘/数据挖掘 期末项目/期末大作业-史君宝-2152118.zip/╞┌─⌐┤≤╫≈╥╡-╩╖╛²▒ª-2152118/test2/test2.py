
import pandas as pd

from sklearn.preprocessing import LabelEncoder

from sklearn.preprocessing import StandardScaler 

from sklearn.model_selection import train_test_split


from sklearn.linear_model import LogisticRegression 
from sklearn.metrics import log_loss

from sklearn.ensemble import RandomForestClassifier

from xgboost import XGBClassifier 


def data_process():
    train_df = pd.read_csv("d:\\playground-series-s3e26\\train.csv")

    train_df = train_df.drop('id', axis=1)
    train_df.head(5)
    train_df.info()

    categorical_cols = ['Drug', 'Sex', 'Ascites', 'Hepatomegaly', 'Spiders', 'Edema', 'Status']

    train_df.describe()

    train_df['Status'].value_counts()

    label_encoder = LabelEncoder() 
    train_df['Status'] = label_encoder.fit_transform(train_df['Status'])

    train_df['Status'].value_counts()

    print("Number of missing feature values by column: ")
    print(train_df.isna().sum())


    numerical_cols = train_df.columns.difference(categorical_cols)

    std_scaler = StandardScaler() 
    std_scaler.fit(train_df[numerical_cols])

    train_df[numerical_cols] = std_scaler.transform(train_df[numerical_cols])



    unique_values_per_column = train_df.nunique()
    print(unique_values_per_column)


    status = train_df['Status']
    train_df_dummies = pd.get_dummies(train_df.drop('Status', axis=1))
    train_df = pd.concat([train_df_dummies, status], axis=1)

    X = train_df.drop("Status", axis=1)
    y = train_df["Status"]

    X_train, X_val, y_train, y_val = train_test_split(X, y,  test_size = 0.2)






    test_df = pd.read_csv("d:\\playground-series-s3e26\\test.csv")

    test_id_df = test_df['id'].astype(int)
    test_df = test_df.drop('id', axis=1)

    print("Number of missing feature values by column in test data:", test_df.isna().sum().sum())

    test_df[numerical_cols] = std_scaler.transform(test_df[numerical_cols])
                      
    test_df.describe()

    
    test_df = pd.get_dummies(test_df)

    test_df.info()

    return X_train, X_val, y_train, y_val, test_df, test_id_df




















def Logic_regression(X_train, X_val, y_train, y_val, test_df):
    model = LogisticRegression(max_iter = 1000)
    model.fit(X_train, y_train)

    y_val_pred_lr = model.predict_proba(X_val)
    y_pred_lr = model.predict_proba(test_df)
    print(y_val_pred_lr, "\n")

    loss = log_loss(y_val, y_val_pred_lr)
    print(f'Validation Set Log Loss: {loss}')



def Random_forest(X_train, X_val, y_train, y_val, test_df):

    rf_classifier = RandomForestClassifier()
    rf_classifier.fit(X_train, y_train) 

    y_val_pred_rf = rf_classifier.predict_proba(X_val)
    y_pred_rf = rf_classifier.predict_proba(test_df)
    print(y_val_pred_rf, "\n")

    loss = log_loss(y_val, y_val_pred_rf)
    print(f'Validation Set Log Loss: {loss}')




def XGB_regress(X_train, X_val, y_train, y_val, test_df):
    xgb_model = XGBClassifier(n_estimators=100, max_depth=2) 
    xgb_model.fit(X_train, y_train)

    y_val_pred_xgb = xgb_model.predict_proba(X_val)
    y_pred_xgb = xgb_model.predict_proba(test_df)
    print(y_val_pred_xgb, "\n")

    loss = log_loss(y_val, y_val_pred_xgb)
    print(f'Validation Set Log Loss: {loss}')

    return y_pred_xgb




if __name__ == '__main__':

    X_train, X_val, y_train, y_val, test_df, test_id_df = data_process()

    Logic_regression(X_train, X_val, y_train, y_val, test_df)

    Random_forest(X_train, X_val, y_train, y_val, test_df)

    y_pred_xgb = XGB_regress(X_train, X_val, y_train, y_val, test_df)


    submission_df = pd.DataFrame(y_pred_xgb, columns=['Status_C', 'Status_CL', 'Status_D'])
    final_submission_df = pd.concat([test_id_df, submission_df], axis=1)
    final_submission_df.head(10)

    final_submission_df.to_csv('d:\\playground-series-s3e26\\submission.csv', index = False)