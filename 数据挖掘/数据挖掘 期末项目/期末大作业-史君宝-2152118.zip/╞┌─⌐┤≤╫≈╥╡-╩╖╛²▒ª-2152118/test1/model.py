from torch import nn
import torch.nn.functional as F

class NeuralNetwork(nn.Module):
    def __init__(self, INPUT_LAYER, l1= 256, l2= 100, l3= 10):
        super(NeuralNetwork,self).__init__()
        self.fc1 = nn.Linear(INPUT_LAYER, l1)
        self.fc2 = nn.Linear (l1, l2)
        self.fc3 = nn.Linear (l2, l3)
        self.fc4 = nn.Linear (l3, 3)
    
    def forward (self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        return self.fc4(x)
    

def objective(trial):
    l1 = trial.suggest_int('l1', 2, 256)
    l2 = trial.suggest_int('l2', 2, 256)
    l3 = trial.suggest_int('l3', 2, 256)
    lr = trial.suggest_loguniform('lr', 1e-4, 1e-1)
    model = NeuralNetwork(l1=l1, l2=l2, l3=l3)
    crit = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    for epoch in range(1000):
        outputs = model(X_train)
        loss = crit(outputs, y_train)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        output = model(X_val)
        valid_loss = crit(output, y_val)
        print(valid_loss)
    return valid_loss.item()


study = optuna.create_study(direction='minimize') 
study.optimize(objective, n_trials=20)