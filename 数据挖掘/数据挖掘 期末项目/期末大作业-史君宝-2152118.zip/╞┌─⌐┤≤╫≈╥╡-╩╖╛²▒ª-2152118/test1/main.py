import pandas as pd
import torch 
from torch import nn
import torch.nn.functional as F

import data_process
import model



if __name__ == '__main__':
    
    X_train, y_train, X_val, y_val, categorical_cols = data_process.train_data_process()

    INPUT_LAYER = int(X_train.shape[1])

    model = model.NeuralNetwork(INPUT_LAYER)        
    crit = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.004695479567227815)

    model

    train_loss = []
    val_loss = []

    for epoch in range(5000):
        if epoch%100 == 0:
            print (f"Epoch {epoch}")

        outputs = model(X_train)
        loss = crit(outputs, y_train)
        
        optimizer.zero_grad()
        train_loss.append(loss)
        loss.backward()
        optimizer.step()


    test = data_process.test_data_process(categorical_cols)

    logits = F.softmax(model(test), dim=1)

    submission = pd.read_csv("d:\\桌面资料\\数据挖掘 期末项目\\playground-series-s3e26\\sample_submission.csv")

    submission['Status_C'] = logits[:, 0].detach().numpy()
    submission['Status_CL'] = logits[:, 1].detach().numpy()
    submission['Status_D'] = logits[:, 2].detach().numpy()

    
    print(submission)


    submission.to_csv('d:\\桌面资料\\数据挖掘 期末项目\\submission.csv', index=False)






"""

def objective(trial):
    l1 = trial.suggest_int('l1', 2, 256)
    l2 = trial.suggest_int('l2', 2, 256)
    l3 = trial.suggest_int('l3', 2, 256)
    lr = trial.suggest_loguniform('lr', 1e-4, 1e-1)

    model = NeuralNetwork(l1=l1, l2=l2, l3=l3)
    crit = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    for epoch in range(1000):
        outputs = model(X_train)
        loss = crit(outputs, y_train)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
    with torch.no_grad():
        output = model(X_val)
        valid_loss = crit(output, y_val)
        print(valid_loss)
    return valid_loss.item()


run = 0

if run ==1:
    study = optuna.create_study(direction='minimize') 
    study.optimize(objective, n_trials=20)



    
    











"""

