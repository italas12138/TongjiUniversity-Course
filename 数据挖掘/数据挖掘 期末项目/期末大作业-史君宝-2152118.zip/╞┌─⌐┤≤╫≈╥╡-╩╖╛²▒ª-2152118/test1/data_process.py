import pandas as pd
import numpy as np 
import torch 
from sklearn.model_selection import train_test_split 



def train_data_process():
    train = pd.read_csv("d:\\桌面资料\\数据挖掘 期末项目\\playground-series-s3e26\\train.csv")

    categorical_cols = list(train.select_dtypes(include = 'object').columns)
    for cols in categorical_cols:
        print (f"The {cols} column has {train[cols].nunique()} unique values")

    encode_categorical(train, categorical_cols)

    y = train.pop('Status')
    X = train

    X.drop('id', inplace=True, axis=1)


    X_train, X_val, y_train , y_val = train_test_split(X,y, test_size=0.3)

    X_train = torch.tensor(X_train.values, dtype=torch.float32)
    y_train = torch.tensor(y_train.values, dtype=torch.long) 
    X_val = torch.tensor(X_val.values, dtype=torch.float32)
    y_val = torch.tensor(y_val.values, dtype=torch.long) 

    return  X_train, y_train, X_val, y_val, categorical_cols



def encode_categorical(df, cat_cols):
    for cols in cat_cols:
        unique_values = list(df[cols].unique())
        if df[cols].nunique() == 2:
            df[cols] = df[cols].map({unique_values[0] : 0, unique_values[1] : 1}).astype('int')
        else: 
            df[cols] = df[cols].map({unique_values[0] : 0, unique_values[1] : 1, unique_values[2] : 2}).astype('int')




def test_data_process(categorical_cols):

    test = pd.read_csv('d:\\桌面资料\\数据挖掘 期末项目\\playground-series-s3e26\\test.csv')

    print("TEST!!")

    categorical_cols.remove('Status')

    test.drop(['id'], inplace=True , axis=1)

    encode_categorical(test, categorical_cols)

    test = torch.tensor(test.values, dtype=torch.float32)

    return test
