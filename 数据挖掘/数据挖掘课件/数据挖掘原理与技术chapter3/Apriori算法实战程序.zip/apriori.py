# -*- coding: utf-8 -*-

import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

shopping_list = [['豆奶','莴苣'],
                 ['莴苣','尿布','葡萄酒','甜菜'],
                 ['豆奶','尿布','葡萄酒','橙汁'],
                 ['莴苣','豆奶','尿布','葡萄酒'],
                 ['莴苣','豆奶','尿布','橙汁']]  # 商店交易信息

te = TransactionEncoder()  # 使用TransactionEncoder将原始数据转为mlxtend接受的特定数据格式
df_tf = te.fit_transform(shopping_list)  # 转为布尔值的array
# print(df_tf)

df = pd.DataFrame(df_tf, columns=te.columns_)  # 转为dataframe形式，将列名转化为原来的商品名
print(df)

# 设置最小支持度min_support=0.4求频繁项集，use_colnames表示使用商品品表示项目
frequent_itemsets = apriori(df, min_support=0.4, use_colnames=True)
# 设置按照支持度从大到小排序
frequent_itemsets.sort_values(by='support', ascending=False, inplace=True)
print(frequent_itemsets)

# 设置使用最小置信度=0.9来求关联规则
rules = association_rules(frequent_itemsets,metric='confidence',min_threshold=0.9)
# 设置按照置信度重大到小排序
rules.sort_values(by='confidence', ascending=False, inplace=True)
show_rules = rules[['antecedents', 'consequents', 'support', 'confidence']]
print(show_rules)

import random
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import networkx as nx

matplotlib.rcParams['font.sans-serif'] = ['KaiTi']
matplotlib.rcParams['font.serif'] = ['KaiTi']

support = rules['support'].values
confidence = rules['confidence'].values

# 因为很多规则有相同的支持度和置信度，这里给每个规则加上了随机数以显示所有的点
for i in range(len(support)):
    support[i] = support[i] + 0.0025 * (random.randint(1, 10) - 5)
    confidence[i] = confidence[i] + 0.0025 * (random.randint(1, 10) - 5)

plt.scatter(support, confidence, marker="*")
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Association Rules')
plt.show()


def draw_graph(rules, rules_to_show):
    G1 = nx.DiGraph()

    color_map = []
    N = 50
    colors = np.random.rand(N)

    strs = ['R0', 'R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9', 'R10', 'R11']
    for i in range(rules_to_show):
        G1.add_nodes_from(["R" + str(i)])  # 添加规则节点

        for a in rules.iloc[i]['antecedents']:  # 添加规则前导项
            G1.add_nodes_from([a])
            G1.add_edge(a, "R" + str(i), color=colors[i], weight=2)

        for c in rules.iloc[i]['consequents']:  # 添加规则后继项
            G1.add_nodes_from([c])
            G1.add_edge("R" + str(i), c, color=colors[i], weight=2)

    for node in G1:
        found_a_string = False
        for item in strs:
            if node == item:
                found_a_string = True
        if found_a_string:
            color_map.append('yellow')  # 规则节点使用黄色
        else:
            color_map.append('green')  # 项集节点使用绿色

    edges = G1.edges()
    colors = [G1[u][v]['color'] for u, v in edges]
    weights = [G1[u][v]['weight'] for u, v in edges]

    pos = nx.spring_layout(G1, k=16, scale=1)
    nx.draw(G1, pos, edges=edges, node_color=color_map, edge_color=colors, width=weights,
            font_size=16, with_labels=False)
    for p in pos:
        pos[p][1] += 0.1
    nx.draw_networkx_labels(G1, pos)
    plt.show()


draw_graph(rules, 1)
draw_graph(rules, 7)
