# 其他文件导入
import data
import train
import predict
import show_result

# 导入其他包
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import transforms, datasets
import random
import os
import time


from torch.utils.data import TensorDataset

if __name__ == '__main__':

    # 数据预处理过程
    train_images, train_labels, val_images, val_labels, test_images, test_labels = data.data_process()

    # 训练过程
    bs = 64
    lr = 0.01
    epoches = 20

    checkpoints = 'train_model'
    os.makedirs(checkpoints, exist_ok=True)

    transform = transforms.Compose([
        transforms.ToTensor()
    ])


    # 转换为TensorDataset
    train_dataset = TensorDataset(torch.from_numpy(train_images).float(), torch.from_numpy(train_labels).long())
    val_dataset = TensorDataset(torch.from_numpy(val_images).float(), torch.from_numpy(val_labels).long())


    train_data = DataLoader(train_dataset, batch_size=bs, shuffle=True, num_workers=0)
    val_data = DataLoader(val_dataset, batch_size=bs, shuffle=True, num_workers=0)

    print('确认训练模型和训练数据集......................')
    print(len(train_dataset))
    print(len(val_dataset))

    class FcNet(nn.Module):
        def __init__(self, input_size, hidden_size_1, hidden_size_2, num_classes):
            super(FcNet, self).__init__()
            self.model = nn.Sequential(
            nn.Linear(input_size, hidden_size_1),
            nn.LeakyReLU(inplace=True),
            nn.Linear(hidden_size_1, hidden_size_2),
            nn.LeakyReLU(inplace=True),
            nn.Linear(hidden_size_2, num_classes),
            nn.LeakyReLU(inplace=True)
        )

        def forward(self, x):
            x = self.model(x)
            return x
    
        
    model = FcNet(input_size=28*28, hidden_size_1=300, hidden_size_2=100, num_classes=10)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)

    if device.type == 'cuda':
        print('使用的是GPU')
    else:
        print('使用的是CPU')

    print()
    loss_func = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=lr, weight_decay=1e-3)

    train.train(5, model, loss_func, optimizer, checkpoints, epoches, train_data, val_data, device)

    predict_num = predict.predict(test_images, test_labels, model)

    show_result.showresult(predict_num)