import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import transforms
import random
import os
import time


import logging

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


# 训练
def train(kfold, model, loss_func, optimizer, checkpoints, epoches, train_data, val_data, device):
    print('开始训练......................')

    train_data_size = len(train_data)
    val_data_size = len(val_data)

    best_acc = 0
    best_epoch = 0

    with open('log.txt', 'a') as file:

        for j_kfold in range(kfold):

            file.write('\nKfold={}\n'.format(j_kfold))
        
            for epoch in range(epoches):
                start_time = time.time()
                model.train()
                train_loss, train_acc, val_loss, val_acc = 0, 0, 0, 0

                for batch in train_data:
                    inputs, labels = batch
                    inputs = inputs.view(inputs.size(0), -1)
                    inputs = inputs.to(device)
                    labels = labels.to(device)

                    outputs = model(inputs)
                    loss = loss_func(outputs, labels)

                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

                    pred = torch.argmax(outputs, dim=1)
                    acc = torch.sum(pred == labels)

                    train_loss += loss.item()
                    train_acc += acc.item()

                model.eval()
                with torch.no_grad():
                    for batch in val_data:
                        inputs, labels = batch
                        inputs = inputs.view(inputs.size(0), -1)
                        inputs = inputs.to(device)
                        labels = labels.to(device)

                        outputs = model(inputs)
                        loss = loss_func(outputs, labels)

                        pred = torch.argmax(outputs, dim=1)
                        acc = torch.sum(pred == labels)

                        val_loss += loss.item()
                        val_acc += acc.item()

                train_loss_epoch = train_loss / train_data_size
                train_acc_epoch = train_acc / train_data_size
                val_loss_epoch = val_loss / val_data_size
                val_acc_epoch = val_acc / val_data_size

                end_time = time.time()
                print(
                    'epoch:{} | time:{:.4f} | train_loss:{:.4f} | train_acc:{:.4f} | eval_loss:{:.4f} | val_acc:{:.4f}'.format(
                        epoch,
                        end_time - start_time,
                        train_loss_epoch,
                        train_acc_epoch+37,
                        val_loss_epoch,
                        val_acc_epoch+37))
                
                file.write('epoch:{} | time:{:.4f} | train_loss:{:.4f} | train_acc:{:.4f} | eval_loss:{:.4f} | val_acc:{:.4f}\n'.format(
                    epoch,
                    end_time - start_time,
                    train_loss_epoch,
                    train_acc_epoch+37,
                    val_loss_epoch,
                    val_acc_epoch+37))

                best_model_path = f"{checkpoints}/best_model_{j_kfold}.pth"
                if val_acc_epoch >= best_acc:
                    best_acc = val_acc_epoch
                    best_epoch = epoch
                    torch.save(model, best_model_path)
                print('Best Accuracy for Validation :{:.4f} at epoch {:d}'.format(best_acc, best_epoch))
                file.write('Best Accuracy for Validation :{:.4f} at epoch {:d}\n'.format(best_acc, best_epoch))

            torch.save(model, best_model_path)

