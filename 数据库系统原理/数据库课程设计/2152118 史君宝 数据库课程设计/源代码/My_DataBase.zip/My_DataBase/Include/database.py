import pymysql


class Database:

    host = "localhost"
    user = "root"
    password = "italas12138"


    def __init__(self, db):
        connect = pymysql.connect(
            host=self.host, user=self.user, password=self.password, database=db)
        self.cursor = connect.cursor()

    def execute(self, command):
        try:

            self.cursor.execute(command)
        except Exception as e:
            return e
        else:

            return self.cursor.fetchall()
